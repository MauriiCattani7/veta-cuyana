/* CAPA DE DATOS de Veta Cuyana.
   Hoy todo se guarda en el localStorage del navegador: sirve para armar y probar la página,
   pero los datos viven solo en esa computadora y esa persona. Para tener cuentas reales
   (que entren desde cualquier dispositivo) hay que reemplazar el contenido de este archivo
   por un servidor (Supabase, Firebase, etc.). El resto de la página solo usa las funciones de DB. */
const DB=(()=>{
  const K={u:"vc-users",s:"vc-session",o:"vc-ofertas",p:"vc-postulaciones"};
  const rd=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}};
  const wr=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}};
  const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
  const norm=e=>String(e||"").trim().toLowerCase();

  /* contraseña: se guarda un hash, nunca el texto. (Con un servidor real esto lo hace el servidor.) */
  async function hash(pw,salt){
    const s=salt+"|"+pw;
    try{
      const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(s));
      return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("");
    }catch(e){let h=5381;for(const c of s)h=((h<<5)+h+c.charCodeAt(0))|0;return "f"+(h>>>0).toString(16)}
  }

  /* ---------- cuentas y sesión ---------- */
  const users=()=>rd(K.u,[]);
  async function register(d){
    const email=norm(d.email);
    if(users().some(u=>u.email==email))return{error:"Ya existe una cuenta con ese correo."};
    const u={...(d.extra||{}),id:uid(),rol:d.rol,email,nombre:d.nombre.trim(),hash:await hash(d.password,email),creado:Date.now()};
    const l=users();l.push(u);
    if(!wr(K.u,l))return{error:"No se pudo guardar la cuenta: el navegador bloquea el almacenamiento."};
    wr(K.s,{id:u.id});return{user:u};
  }
  async function login(email,password){
    email=norm(email);
    const u=users().find(x=>x.email==email);
    if(!u||u.hash!==await hash(password,email))return{error:"Correo o contraseña incorrectos."};
    wr(K.s,{id:u.id});return{user:u};
  }
  function me(){const s=rd(K.s,null);return s&&users().find(x=>x.id==s.id)||null}
  function logout(){try{localStorage.removeItem(K.s)}catch(e){}}
  const home=rol=>rol=="empresa"?"empresa.html":"index.html";
  /* protege una página: sin sesión va al login; con otro tipo de cuenta, a su propia página */
  function guard(rol){
    const u=me();
    if(!u){location.replace("login.html");return null}
    if(u.rol!=rol){location.replace(home(u.rol));return null}
    return u;
  }
  function updateProfile(id,patch){
    const l=users(),i=l.findIndex(x=>x.id==id);
    if(i<0)return false;
    l[i]={...l[i],...patch};return wr(K.u,l);
  }
  /* CV: se guarda en el perfil de la persona (máx. 600 KB por el límite del navegador) */
  const MAXCV=600*1024;
  function readCV(file){
    return new Promise(res=>{
      if(file.size>MAXCV)return res({error:"El CV pesa más de 600 KB. Subí una versión más liviana."});
      const r=new FileReader();
      r.onload=()=>res({cv:{name:file.name,data:r.result}});
      r.onerror=()=>res({error:"No se pudo leer el archivo."});
      r.readAsDataURL(file);
    });
  }
  const cvDe=personaId=>(users().find(x=>x.id==personaId)||{}).cv||null;

  /* ---------- ofertas de trabajo ---------- */
  const ofertas=()=>rd(K.o,[]);
  const ofertasAbiertas=()=>ofertas().filter(o=>o.estado=="abierta");
  const ofertaPorId=id=>ofertas().find(o=>o.id==id)||null;
  const ofertasDe=empresaId=>ofertas().filter(o=>o.empresaId==empresaId).sort((a,b)=>b.creada-a.creada);
  function publish(empresa,d){
    const o={...d,id:uid(),empresaId:empresa.id,empresa:empresa.nombre,estado:"abierta",creada:Date.now()};
    const l=ofertas();l.push(o);
    return wr(K.o,l)?{oferta:o}:{error:"No se pudo guardar la oferta."};
  }
  function setOferta(id,patch){const l=ofertas(),i=l.findIndex(x=>x.id==id);if(i>=0){l[i]={...l[i],...patch};wr(K.o,l)}}
  function delOferta(id){wr(K.o,ofertas().filter(x=>x.id!=id))}
  /* mismo formato que las vacantes de data.js:
     [puesto, empresa, categoría, mineral, ubicación, régimen, renta, altura, alojamiento, urgente, id] */
  const toArr=o=>[o.puesto,o.empresa,o.cat,o.mineral,o.ubicacion,o.regimen,o.renta,o.altura,o.alojamiento,o.urgente?1:0,o.id];

  /* ---------- postulaciones ---------- */
  const posts=()=>rd(K.p,[]);
  const postsDePersona=id=>posts().filter(p=>p.personaId==id);
  const postsDeEmpresa=id=>posts().filter(p=>p.empresaId==id);
  /* of: {id, puesto, empresa, empresaId}; persona: la cuenta (se copian sus datos de contacto) */
  function postular(persona,of){
    const l=posts();
    if(l.some(p=>p.personaId==persona.id&&p.ofertaId==of.id))return{error:"Ya te postulaste a este puesto."};
    const p={id:uid(),ofertaId:of.id,empresaId:of.empresaId||null,puesto:of.puesto,empresa:of.empresa,
      personaId:persona.id,nombre:persona.nombre,email:persona.email,whatsapp:persona.whatsapp||"",
      experiencia:persona.experiencia||"",altura:persona.altura||"",estado:"nuevo",fecha:Date.now()};
    l.push(p);
    return wr(K.p,l)?{post:p}:{error:"No se pudo guardar la postulación."};
  }
  function setEstado(id,estado){const l=posts(),i=l.findIndex(x=>x.id==id);if(i>=0){l[i].estado=estado;wr(K.p,l)}}
  function retirar(id,personaId){wr(K.p,posts().filter(p=>!(p.id==id&&p.personaId==personaId)))}

  return{register,login,me,logout,home,guard,updateProfile,readCV,cvDe,
    ofertasAbiertas,ofertaPorId,ofertasDe,publish,setOferta,delOferta,toArr,
    postsDePersona,postsDeEmpresa,postular,setEstado,retirar};
})();

/* Mis postulaciones: a qué puestos y empresas se postuló la persona y cómo va cada una */
const U=DB.guard("persona")||{};
initAccount(U);
let fe="";

const ESTP={nuevo:"Enviada",visto:"Vista por la empresa",pre:"Preseleccionado/a",desc:"No continúa en el proceso"};

function render(){
  const ps=DB.postsDePersona(U.id).sort((a,b)=>b.fecha-a.fecha);
  const emp=[...new Set(ps.map(p=>p.empresa))];
  if(fe&&!emp.includes(fe))fe="";
  $("ds").textContent=U.nombre||"";

  $("stats").innerHTML=[[ps.length,"Postulaciones enviadas"],[emp.length,"Empresas"],[ps.filter(p=>p.estado=="pre").length,"Preseleccionado/a"]]
    .map(s=>`<div class="stat"><b>${s[0]}</b><span>${s[1]}</span></div>`).join("");

  /* filtro por empresa */
  $("tabs").innerHTML=emp.length>1?[["","Todas"]].concat(emp.map(e=>[e,e])).map(c=>`<button class="chip${fe==c[0]?" on":""}" data-e="${esc(c[0])}">${esc(c[1])}</button>`).join(""):"";

  const lst=ps.filter(p=>!fe||p.empresa==fe);
  if(!ps.length){
    $("pl").innerHTML=`<div class="vacio"><h3>Todavía no te postulaste a ningún puesto</h3><p>Buscá una vacante y postulate. Acá vas a ver a qué empresas te postulaste y cómo avanza cada una.</p><a class="btn pri" href="index.html" style="text-decoration:none">Buscar vacantes</a></div>`;
    return;
  }
  $("pl").innerHTML=lst.map(p=>`<article class="cand">
      <div class="av">${esc((p.empresa||"?").trim().charAt(0).toUpperCase())}</div>
      <div>
        <h3>${esc(p.puesto)}</h3>
        <div class="co2">${esc(p.empresa)}</div>
        <div class="cm"><span>Te postulaste el ${fdate(p.fecha)}</span></div>
      </div>
      <div class="side">
        <span class="st ${esc(p.estado)}">${esc(ESTP[p.estado]||ESTP.nuevo)}</span>
        <button class="btn" data-r="${p.id}">Retirar postulación</button>
      </div>
    </article>`).join("");
}

$("tabs").onclick=e=>{const c=e.target.closest("[data-e]");if(c){fe=c.dataset.e;render()}};
$("pl").onclick=e=>{
  const b=e.target.closest("[data-r]");if(!b)return;
  if(!confirm("¿Retirar esta postulación?"))return;
  DB.retirar(b.dataset.r,U.id);toast("Postulación retirada");render();
};

render();
